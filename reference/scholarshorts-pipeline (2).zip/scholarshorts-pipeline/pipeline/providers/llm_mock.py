import hashlib
import json
import re
from pathlib import Path

GOLDEN = Path(__file__).resolve().parents[2] / "golden" / "flowmap_2610.20674"
SEEN: set[str] = set()


def est_tokens(s: str) -> int:
    h = len(re.findall(r"[가-힣]", s))
    return int(h / 1.3 + (len(s) - h) / 3.6)


def simulate_cache(prompt):
    usage = {"input_tokens": 0, "cache_write_tokens": 0, "cache_read_tokens": 0}
    prefix = ""
    for b in prompt.system + prompt.user:
        prefix += b.text
        n = est_tokens(b.text)
        if not b.cache:
            usage["input_tokens"] += n
            continue
        key = hashlib.sha256(prefix.encode()).hexdigest()
        usage["cache_read_tokens" if key in SEEN else "cache_write_tokens"] += n
        SEEN.add(key)
    return usage


class MockLLM:
    def __init__(self, model: str, api_key: str = "", **_):
        self.model = model

    def complete(self, prompt, images=None, max_tokens=8000):
        t = prompt.text()
        if "You build a fact sheet" in t:
            out = (GOLDEN / "facts.json").read_text()
        elif "You write the storyboard" in t:
            out = (GOLDEN / "storyboard.json").read_text()
        elif "You write one Manim scene file" in t:
            sid = re.search(r'"scene_id":"(S\d+)"', prompt.user[0].text).group(1)
            helpers = (GOLDEN / "scenes" / "_shared.py").read_text().split("def sig")[1]
            code = (GOLDEN / "scenes" / f"{sid}.py").read_text().replace("from _shared import *\n", "from _shared import *\n\n\ndef sig" + helpers + "\n")
            out = f"```python\n{code}```"
        elif "You review preview frames" in t:
            out = '{"issues": []}'
        elif "You check a finished short video" in t:
            ids = sorted(set(re.findall(r'"line_id":"(s\w+)"', t)))
            out = json.dumps({"claim_verdicts": [{"line_id": i, "verdict": "supported", "note": "mock"} for i in ids], "onscreen_issues": []})
        else:
            raise ValueError("mock: unknown prompt")
        usage = simulate_cache(prompt)
        usage["output_tokens"] = est_tokens(out)
        usage["image_tokens"] = 0
        for img in images or []:
            from PIL import Image
            import io
            w, h = Image.open(io.BytesIO(img)).size
            s = min(1.0, 2576 / max(w, h))
            w, h = int(w * s), int(h * s)
            usage["input_tokens"] += -(-w // 28) * -(-h // 28)
        return out, usage
