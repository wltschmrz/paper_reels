import base64

import anthropic


def _blocks(blocks):
    out = []
    for b in blocks:
        d = {"type": "text", "text": b.text}
        if b.cache:
            d["cache_control"] = {"type": "ephemeral"}
        out.append(d)
    return out


class AnthropicLLM:
    def __init__(self, model: str, api_key: str, temperature: float = 0.4):
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model, self.temperature = model, temperature

    def complete(self, prompt, images=None, max_tokens=8000):
        cached = [b for b in prompt.user if b.cache]
        fresh = [b for b in prompt.user if not b.cache]
        imgs = [{"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": base64.b64encode(i).decode()}}
                for i in (images or [])]
        content = _blocks(cached) + imgs + _blocks(fresh)
        r = self.client.messages.create(model=self.model, max_tokens=max_tokens, temperature=self.temperature,
                                        system=_blocks(prompt.system), messages=[{"role": "user", "content": content}])
        text = "".join(b.text for b in r.content if b.type == "text")
        u = r.usage
        return text, {"input_tokens": u.input_tokens, "output_tokens": u.output_tokens,
                      "cache_write_tokens": getattr(u, "cache_creation_input_tokens", 0) or 0,
                      "cache_read_tokens": getattr(u, "cache_read_input_tokens", 0) or 0}
