import json
import re
import sys

HEAD = re.compile(r"^(?:(\d+(?:\.\d+)*|[A-H](?:\.\d+)*)\s+)?([A-Z][A-Z0-9 \-:,&'’()]{3,})$")
SPECIAL = {"ABSTRACT", "REFERENCES", "ACKNOWLEDGMENTS", "ACKNOWLEDGEMENTS", "AI USE STATEMENT"}


def convert(text, paper_id, title, authors, arxiv_id=None):
    lines = [l.rstrip() for l in text.splitlines()]
    sections, cur, buf = [], {"id": "front", "title": "front matter"}, []
    for l in lines:
        m = HEAD.match(l.strip())
        if m and (m.group(1) or m.group(2).strip() in SPECIAL) and len(l.split()) <= 9:
            sections.append({**cur, "text": "\n".join(buf).strip()})
            num, name = m.group(1), m.group(2).strip()
            cur, buf = {"id": f"sec{len(sections)}", "title": f"{num + ' ' if num else ''}{name.title()}"}, []
        else:
            buf.append(l)
    sections.append({**cur, "text": "\n".join(buf).strip()})
    sections = [s for s in sections if s["text"]]
    abstract = next((s["text"] for s in sections if s["title"].lower() == "abstract"), "")
    tables = []
    for i, l in enumerate(lines):
        m = re.match(r"^(Table \d+):\s*(.*)", l.strip())
        if m:
            tables.append({"id": m.group(1).lower().replace(" ", ""), "label": m.group(1), "caption": m.group(2),
                           "text": "\n".join(lines[i + 1:i + 16])})
    return {"paper_id": paper_id, "arxiv_id": arxiv_id, "source_kind": "pdf", "title": title, "authors": authors,
            "abstract": abstract, "sections": [s for s in sections if s["title"].lower() != "abstract"], "tables": tables}


if __name__ == "__main__":
    src, out, paper_id, title, authors = sys.argv[1:6]
    doc = convert(open(src).read(), paper_id, title, [a.strip() for a in authors.split(",")], paper_id.split(":")[-1])
    json.dump(doc, open(out, "w"), ensure_ascii=False, indent=1)
    print(len(doc["sections"]), "sections:", [s["title"] for s in doc["sections"]][:40])
    print(len(doc["tables"]), "tables")
