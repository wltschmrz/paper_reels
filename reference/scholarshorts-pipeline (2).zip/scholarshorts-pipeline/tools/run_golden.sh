#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
JOB="${1:-/tmp/ss_jobs/golden}"
rm -rf "$JOB" && mkdir -p "$(dirname "$JOB")" && cp -r "$ROOT/golden/flowmap_2610.20674" "$JOB"
cd "$ROOT"
python3 -m pipeline.stages.lint "$JOB"
python3 -m pipeline.runner "$JOB"
python3 -c "import json,sys; d=json.load(open('$JOB/out/validation.json')); [print(c['passed'], c['name'], c['detail']) for c in d['checks']]"
ls -la "$JOB/out"
