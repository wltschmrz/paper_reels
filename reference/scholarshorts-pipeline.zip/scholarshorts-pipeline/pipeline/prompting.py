import json
from pathlib import Path

from .contracts import FactSheet, Storyboard, StyleSpec
from .style_compile import compile_style

P = Path(__file__).parent / "prompts"


def load(name):
    return (P / f"{name}.md").read_text()


def fill(name: str, **slots) -> tuple[str, str]:
    text = load(name).replace("{{FIDELITY_RULES}}", load("fidelity_rules"))
    for k, v in slots.items():
        text = text.replace("{{" + k + "}}", v if isinstance(v, str) else json.dumps(v, ensure_ascii=False, indent=1))
    system, _, user = text.partition("\nUSER\n")
    return system.replace("SYSTEM\n", "", 1).strip(), user.strip()


def understand(paper_json: dict):
    return fill("understand", PAPER_JSON=paper_json, FACTSHEET_SCHEMA=FactSheet.model_json_schema())


def storyboard(facts: FactSheet, style: StyleSpec):
    return fill("storyboard", STYLE_BLOCK=compile_style(style), VISUAL_CATALOG=load("visual_catalog"),
                STORYBOARD_SCHEMA=Storyboard.model_json_schema(), FACTS_JSON=facts.model_dump())


def visual_code(scene: dict, durations: dict, facts: list[dict], style: StyleSpec, golden_example: str, repair: str = ""):
    return fill("visual_code", SCENE_ID=scene["scene_id"], STYLE_BLOCK=compile_style(style), RENDER_KIT_API=load("render_kit_api"),
                GOLDEN_EXAMPLE=golden_example, SCENE_JSON=scene, DURATIONS_JSON=durations, FACTS_JSON=facts, REPAIR_CONTEXT=repair)


def visual_qa(scene: dict):
    return fill("visual_qa", SCENE_JSON=scene)


def judge(timeline: list, onscreen: dict, facts: FactSheet):
    return fill("judge", TIMELINE_JSON=timeline, ONSCREEN_JSON=onscreen, FACTS_JSON=facts.model_dump())
