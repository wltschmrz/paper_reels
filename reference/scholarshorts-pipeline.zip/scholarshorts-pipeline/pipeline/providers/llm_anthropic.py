import base64

import anthropic


class AnthropicLLM:
    def __init__(self, model: str, api_key: str, temperature: float = 0.4):
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model, self.temperature = model, temperature

    def complete(self, system, user, images=None, max_tokens=8000):
        content = [{"type": "image", "source": {"type": "base64", "media_type": "image/png",
                                                "data": base64.b64encode(b).decode()}} for b in (images or [])]
        content.append({"type": "text", "text": user})
        r = self.client.messages.create(model=self.model, max_tokens=max_tokens, temperature=self.temperature,
                                        system=system, messages=[{"role": "user", "content": content}])
        text = "".join(b.text for b in r.content if b.type == "text")
        return text, {"input_tokens": r.usage.input_tokens, "output_tokens": r.usage.output_tokens}
